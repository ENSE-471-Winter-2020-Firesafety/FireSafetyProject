function errorHint(){
	document.getElementById("hintMessage").innerHTML = "Woops. Try Again!";
}

function correctHint(){
	document.getElementById("hintMessage").innerHTML = "Good Job!";
	document.getElementById("correctSfx").play();

	setTimeout(() => {window.location = "dialScreen.html";}, 2500);
}

function settings(){
	document.getElementById("hintMessage").innerHTML = "Woops. Try Again!";
	setTimeout(() => {window.location = "instructorSetting.html";}, 500);
}

var id = 0;
function instructorScript(){
	setTimeout(() => {window.location = "instructorScript.html";}, 500);
}

function returnHome(){
	setTimeout(() => {window.location = "index.html";}, 500);
}
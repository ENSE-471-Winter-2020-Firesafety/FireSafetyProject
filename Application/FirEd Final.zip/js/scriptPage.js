function returnToScript(){
	setTimeout(() => {window.location = "instructorScript.html";}, 500);
}

function goAddress(){
	setTimeout(() => {window.location = "instructorSetting.html";}, 500);
}

function meeting(){
	setTimeout(() => {window.location = "meetingPoint.html";}, 500);
}

function number(){
	setTimeout(() => {window.location = "phoneNumber.html";}, 500);
}

function returnTo(){
	setTimeout(() => {window.location = "instructorSetting.html";}, 500);
}
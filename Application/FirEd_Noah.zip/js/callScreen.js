function endCall(){
    setTimeout(() => {window.location = "index.html";}, 500);
}

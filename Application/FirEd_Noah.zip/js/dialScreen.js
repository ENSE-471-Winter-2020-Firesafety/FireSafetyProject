var dialedNumber = [];

function addNum(num){
    dialedNumber.push(num);
    document.getElementById("dialText").innerHTML = dialedNumber.join("");
}

function deleteNum(){
    dialedNumber.pop();
    document.getElementById("dialText").innerHTML = dialedNumber.join("");
}

function call(){
    if (dialedNumber.join("") == "911")
    {
        document.getElementById("msgText").innerHTML = "Awesome!";
        setTimeout(() => {window.location = "callscreen.html";}, 2500);
    }
    else
    {
        document.getElementById("msgText").innerHTML = "test";
    }
}

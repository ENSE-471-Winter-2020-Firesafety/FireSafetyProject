var dialedNumber = [];

function addNum(num){
    dialedNumber.push(num);
    document.getElementById("dialText").innerHTML = dialedNumber.join("");
}

function deleteNum(){
    dialedNumber.pop();
    document.getElementById("dialText").innerHTML = dialedNumber.join("");

    if (dialedNumber.length == 0)
    {
        document.getElementById("msgText").innerHTML = "";
    }
}

function call(){
    if (dialedNumber.join("") == "911")
    {
        document.getElementById("msgText").innerHTML = "Awesome!";
        setTimeout(() => {window.location = "callscreen.html";}, 800);
    }
    else
    {
        document.getElementById("msgText").innerHTML = "test";
    }
}

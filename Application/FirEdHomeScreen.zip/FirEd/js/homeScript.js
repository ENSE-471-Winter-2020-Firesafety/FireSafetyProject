function errorHint(){
	document.getElementById("hintMessage").innerHTML = "Woops. Try Again!";
}

function correctHint(){
	document.getElementById("hintMessage").innerHTML = "Good Job!";
	document.getElementById("correctSfx").play();

	setTimeout(() => {window.location = "instructorSetting.html";}, 2500);
}